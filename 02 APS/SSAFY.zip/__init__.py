import algo 

algo = algo.Algo()
# algo.workspace_APS()
algo.package_each_day()