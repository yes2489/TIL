package com.ssafy.mvc.model.service;

public interface UserService {

}
