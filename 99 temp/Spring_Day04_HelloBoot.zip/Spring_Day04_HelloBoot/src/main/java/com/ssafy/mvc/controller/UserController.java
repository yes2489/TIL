package com.ssafy.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.ssafy.mvc.model.dto.User;

import jakarta.servlet.http.HttpSession;


@Controller
public class UserController {
	// 정석 : Service를 의존성 주입 받아야 함
	
//	@Autowired
//	private final UserService userService;
	
////	@Autowired
//	public void setUserService(UserService userService) {
//		this.userService = userService;
//	}
//	
////	@Autowired
//	public void setUserController(UserService userService) {
//		this.userService = userService;
//	}
	
	@GetMapping("/login")
	public String loginForm() {
		return "/user/loginform";
	}
	
	@PostMapping("/login")
	public String login(@ModelAttribute User user, HttpSession session) {
//		User loginUser = UserService.login(user); // pw까지 저장되어버림
		
		System.out.println(user);
		
		// 세션에 저장 -> 세션 가져오기
//		HttpSession session = req.getSession();
		
		// 지금은 서비스를 구현하지 않아서 넘겨받은 user의 id를 넣음 but, 실제 구현 뒤에는 인증받은 정보만을 넣기 (pw제외)
		session.setAttribute("loginUser", user.getId());
		
		
		return "redirect:hello";
	}
	
//	@PostMapping("/login")
//	public String login(@RequestParam("id")String id, @RequestParam("pw")String pw) {
//		// userService라는 친구를 통해 실제로 id, pw를 이용하여 DB까지 확인하고 실제 유저가 맞는지 확인해야함
//		// 세션에 정보를 저장해야 함
//		
//		System.out.println("id: " + id + " pw :" + pw);
//		
////		return "hello"; // 포워딩 (url 주소가 달라지지 않음)
//		return "redirect:hello"; // 
//	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		// 로그아웃을 하는 방법 2가지
		// 1. 세션에서 유저 속성을 지우는 작업
		session.removeAttribute("loginUser");
		
		// 2. 세션 자체를 초기화
//		session.invalidate();
		
		return "redirect:/";
	}
	
}
