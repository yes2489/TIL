package com.ssafy.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringpracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
