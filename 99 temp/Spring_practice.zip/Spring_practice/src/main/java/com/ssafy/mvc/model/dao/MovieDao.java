package com.ssafy.mvc.model.dao;

import java.util.List;

import com.ssafy.mvc.model.dto.Movie;

public interface MovieDao {
	
	// 현재 등록 영화 수
	int movieCnt();
	
	// 전체 영화 조회
	List<Movie> selectMovieList();
	
	// 특정 영화 조회
	Movie selectMovie(int id);
	
	// 영화 정보 등록
	void insertMovie(Movie movie);
	
	// 영화 정보 수정
	void modifyMovie(Movie movie);
	
	// 영화 정보 삭제
	void deleteMovie(int id);

}
