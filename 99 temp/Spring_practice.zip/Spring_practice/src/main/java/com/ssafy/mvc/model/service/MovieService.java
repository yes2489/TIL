package com.ssafy.mvc.model.service;

import java.util.List;

import com.ssafy.mvc.model.dto.Movie;

public interface MovieService {
	// 영화 조회
	public List<Movie> getMovieList();
	
	// 영화 디테일
	public Movie selectMovie(int id);
	
	// 영화 등록
	public void insertMovie(Movie movie);
	
	// 영화 수정
	public void updateMovie(Movie movie);
	
	// 영화 삭제
	public void removeMovie(int id);
	
}
