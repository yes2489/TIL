package com.ssafy.mvc.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.mvc.model.dto.Movie;
import com.ssafy.mvc.model.service.MovieService;

@Controller
public class MovieController {
	
	private MovieService movieService;
	
	public MovieController(MovieService movieService) {
		this.movieService = movieService;
	}
	
	@GetMapping({"/", "/index"})
	public String showIndex() {
		return "index";
	}
	
	@GetMapping("/list")
	public String list(Model model) {
		List<Movie> movies = movieService.getMovieList();
		
		model.addAttribute("movies", movies);
		
		return "list";
	}
	
	@GetMapping("/regist")
	public String registform() {
		return "regist";
	}
	
	@PostMapping("/regist")
	public String regist(@ModelAttribute Movie movie) {
		
		movieService.insertMovie(movie);
//		movieService.selectMovie(movie.getId());
		
		return "redirect:list";
	}
	
	@GetMapping("/update")
	public String updateform(@RequestParam("id") int id, Model model) {
		model.addAttribute("movie", movieService.selectMovie(id));
		return "update";
	}
	
	@PostMapping("/update")
	public String update(@ModelAttribute Movie movie) {
		movieService.updateMovie(movie);
		return "redirect:detail?id="+movie.getId();
	}
	
	@GetMapping("/detail")
	public String detail(@ModelAttribute Movie movie, Model model) {
		model.addAttribute("movie", movieService.selectMovie(movie.getId()));
		
		return "detail";
	}
}
