package com.ssafy.mvc.controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.mvc.model.dto.Movie;
import com.ssafy.mvc.model.service.MovieService;

@Controller
public class MovieController {
	
	private ResourceLoader resourceLoader;
	
	private MovieService movieService;
	
	public MovieController(MovieService movieService, ResourceLoader resourceLoader) {
		this.movieService = movieService;
		this.resourceLoader=resourceLoader;
	}
	
	@GetMapping({"/", "/index"})
	public String showIndex() {
		return "index";
	}
	
	@GetMapping("/list")
	public String list(Model model) {
		List<Movie> movies = movieService.getMovieList();
		
		model.addAttribute("movies", movies);
		
		return "list";
	}
	
	@GetMapping("/regist")
	public String registform() {
		return "regist";
	}
	
	@PostMapping("/regist")
	public String regist(@ModelAttribute Movie movie, @RequestParam("file") MultipartFile file) throws IllegalStateException, IOException {
		// 파일이 존재하고 size가 0보다 크면
		if (file != null && file.getSize() > 0) {
			
			// 코드로 img폴더 가져와서 옮기기
			// 스프링에서 파일, 클래스 등 resource들을 로드할때는 Resource 활용
			Resource resource = resourceLoader.getResource("classpath:/static/upload");
			System.out.println(resource);
			
			String orgName = file.getOriginalFilename();
			
			// 식별을 위해 저장은 file명에 업로드 날짜 포함
			LocalDate now = LocalDate.now();
			
			String fileName = now + "_" + orgName;
			
			
			// /img 밑에 이미지 저장
			file.transferTo(new File(resource.getFile(), fileName));
			
			// movie 객체에 저장
			movie.setOrgImg(orgName); // 클라이언트가 최초로 저장한 이름
			movie.setImg(fileName); // 구분자 추가한 이미지 이름
			
		}
		
		movieService.insertMovie(movie);
		
		
		return "redirect:list";
	}
	
	@GetMapping("/update")
	public String updateform(@RequestParam("id") int id, Model model) {
		model.addAttribute("movie", movieService.selectMovie(id));
		return "update";
	}
	
	@PostMapping("/update")
	public String update(@ModelAttribute Movie movie, @RequestParam("file") MultipartFile file) throws IllegalStateException, IOException {
		// 파일이 존재하고 size가 0보다 크면
		if (file != null && file.getSize() > 0) {
			
			///////////////기존 이미지 삭제 추가///////////////
			// String rm = movie.getImg();
			/////////////////////////////////////////////
					
			// 코드로 img폴더 가져와서 옮기기
			// 스프링에서 파일, 클래스 등 resource들을 로드할때는 Resource 활용
			Resource resource = resourceLoader.getResource("classpath:/static/upload");
			System.out.println(resource);
					
			String orgName = file.getOriginalFilename();
					
			// 식별을 위해 저장은 file명에 업로드 날짜 포함
			LocalDate now = LocalDate.now();
					
			String fileName = now + "_" + orgName;
			
			// /img 밑에 이미지 저장
			file.transferTo(new File(resource.getFile(), fileName));			
			
			// movie 객체에 저장
			movie.setOrgImg(orgName); // 클라이언트가 최초로 저장한 이름
			movie.setImg(fileName); // 구분자 추가한 이미지 이름
			}
		
		movieService.updateMovie(movie);
		return "redirect:detail?id="+movie.getId();
	}
	
	@GetMapping("/detail")
	public String detail(@ModelAttribute Movie movie, Model model) {
		model.addAttribute("movie", movieService.selectMovie(movie.getId()));
		
		return "detail";
	}
}
