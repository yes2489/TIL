package com.ssafy.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringpracticeApplication {
	
	/*
	 * @Autowired private LoginInterceptor loginInterceptor;
	 */
	
	/*
	 * @Override public void addInterceptors(InterceptorRegistry registry) {
	 * registry.addInterceptor(loginInterceptor) .addPathPatterns("/**") // 모든 경로에
	 * 대해 인터셉터 적용 .excludePathPatterns("/", "/login", "/css/**", "/img/**"); // 로그인
	 * 없이 접근 가능한 곳 }
	 */

	public static void main(String[] args) {
		SpringApplication.run(SpringpracticeApplication.class, args);
	}

}
