package com.ssafy.mvc.model.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.mvc.model.dao.MovieDao;
import com.ssafy.mvc.model.dto.Movie;

@Service
public class MovieServiceImpl implements MovieService{
	
	private final MovieDao movieDao;

	public MovieServiceImpl(MovieDao movieDao) {
		this.movieDao = movieDao;
	}

	@Override
	public List<Movie> getMovieList() {
		System.out.println("영화 전체 목록 조회");
		return movieDao.selectMovieList();
	}

	@Override
	public Movie selectMovie(int id) {
		System.out.println("영화 디테일 조회");
		return movieDao.selectMovie(id);
	}

	@Transactional
	@Override
	public void insertMovie(Movie movie) {
		System.out.println("영화 등록");
		movieDao.insertMovie(movie);
	}

	@Transactional
	@Override
	public void updateMovie(Movie movie) {
		System.out.println("영화 정보 수정");
		movieDao.modifyMovie(movie);
		
	}

	@Transactional
	@Override
	public void removeMovie(int id) {
		System.out.println("영화 삭제");
		movieDao.deleteMovie(id);
	}
	
}
