package com.ssafy.mvc.model.dao;

import com.ssafy.mvc.model.dto.User;

public interface UserDao {
	
	// 회원 조회
	User selectUser(String id);
}
