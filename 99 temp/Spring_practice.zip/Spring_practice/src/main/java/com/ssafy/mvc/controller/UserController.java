package com.ssafy.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.mvc.model.dto.User;
import com.ssafy.mvc.model.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	private UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping("/login")
	public String login(@ModelAttribute User user, HttpSession session) {
		System.out.println("로그인 시도 ID : " + user.getId());
		
		User dbUser = userService.selectUser(user.getId());
		
		System.out.println();
		
		// id가 다르면 dbUser == null
		if(dbUser == null) {
			System.out.println("일치하는 id 없음");
			return "redirect:/";
		}
		
		// id 있고 db저장 비밀번호까지 일치하면 성공
		if(dbUser.getPass().equals(user.getPass())) {
			System.out.println("로그인 성공 : " + dbUser.getName());
			session.setAttribute("loginUser", dbUser.getName());
			return "redirect:/";
		} 
		
		System.out.println("비밀번호가 다름");
		
		return "redirect:/";
		
		
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("loginUser");
		System.out.println("로그아웃");
		return "redirect:/";
	}
}
