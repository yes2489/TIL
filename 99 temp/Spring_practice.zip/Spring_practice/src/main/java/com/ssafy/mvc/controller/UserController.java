package com.ssafy.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.mvc.model.dto.User;
import com.ssafy.mvc.model.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	private UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@GetMapping("/signup")
	public String signupForm() {
		return "/user/signup";
	}
	
	@PostMapping("/signup")
	public String signup(@ModelAttribute User user) {
		userService.signupUser(user);
		return "redirect:list";
	}
	
	@PostMapping("/login")
	public String login(@ModelAttribute User user, HttpSession session) {
		System.out.println("로그인 시도 ID : " + user.getId());
		
		User tmp = userService.selectUser(user.getId(), user.getPass());
		
		if (tmp == null) {
			return "redirect:/";
		}
		
		session.setAttribute("loginUser", tmp.getName());
		
		// 일치 여부 확인
		return "redirect:list";
		
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("loginUser");
		System.out.println("로그아웃");
		return "redirect:/";
	}
}
