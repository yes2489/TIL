package com.ssafy.mvc.model.service;

import com.ssafy.mvc.model.dto.User;

public interface UserService {
	
	// 회원 조회
	User selectUser(String id, String pass);
	
	// 회원 가입
	void signupUser(User user);
	
	// 전체 회원 조회
	User showUsers();
}
