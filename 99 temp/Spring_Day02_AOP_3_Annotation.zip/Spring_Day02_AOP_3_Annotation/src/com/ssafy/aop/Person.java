package com.ssafy.aop;

public interface Person {
	int coding() throws OuchException;
}
