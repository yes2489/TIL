package com.ssafy.di;

public class Laptop implements Computer{
	//필드...
	
	
	public String getInfo() {
		return "랩톱";
	}
}
