package com.ssafy.proxy;

public class Test {
	public static void main(String[] args) {
		Programmer p = new Programmer();
		
		p.coding();
	}
}
