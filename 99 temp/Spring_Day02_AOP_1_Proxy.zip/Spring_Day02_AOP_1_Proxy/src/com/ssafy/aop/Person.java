package com.ssafy.aop;

public interface Person {
	void coding();
}
