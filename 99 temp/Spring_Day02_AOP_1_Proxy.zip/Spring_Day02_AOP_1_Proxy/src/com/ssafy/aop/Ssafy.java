package com.ssafy.aop;

import java.util.Random;

public class Ssafy implements Person {
	// 필드는 생략
	
	// 프로그래머의 일상
	public void coding() {
		System.out.println("열심히 공부를 한다."); // 핵심 관심 사항
	}
}
