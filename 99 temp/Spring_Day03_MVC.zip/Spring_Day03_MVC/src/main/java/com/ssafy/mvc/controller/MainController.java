package com.ssafy.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	// 똑같은 요청이지만 method를 달리 받아서 처리 가능
	
	@RequestMapping(value="/home", method = RequestMethod.GET)
	public ModelAndView homeHandle1() {
		ModelAndView mav = new ModelAndView();
		
		// 데이터를 심어서 보내보자
		mav.addObject("msg", "Welcome to Spring MVC (GET)");
		
		// view 이름 결정 // 포워딩한거랑 같음
		mav.setViewName("home");
		
//		mav.setViewName("redirect:home"); // 리다이렉트 시
		return mav;
	}
	
	@RequestMapping(value="/home", method = RequestMethod.POST)
	public ModelAndView homeHandle2() {
		ModelAndView mav = new ModelAndView();
		
		// 데이터를 심어서 보내보자
		mav.addObject("msg", "Welcome to Spring MVC (POST)");
		
		// view 이름 결정 // 포워딩한거랑 같음
		mav.setViewName("home");
		
//		mav.setViewName("redirect:home"); // 리다이렉트 시
		return mav;
	}
	
	
}
