package com.ssafy.di3_타입의존성제거;

public class Laptop implements Computer{
	//필드...
	
	
	public String getInfo() {
		return "랩톱";
	}
}
