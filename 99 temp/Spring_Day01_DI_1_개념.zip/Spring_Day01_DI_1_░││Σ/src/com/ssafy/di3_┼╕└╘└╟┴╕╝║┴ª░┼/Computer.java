package com.ssafy.di3_타입의존성제거;

public interface Computer {
	String getInfo();
}
