package com.ssafy.di2_객체생성의존성제거;

public class Desktop {
	//멤버필드 작성~~~!
//	private String CPU;
//	private String RAM;
//	... 작성을 할 수 있다. 오늘은 필요없어!
	
	public String getInfo() {
		return "데스크톱";
	}
	
}
