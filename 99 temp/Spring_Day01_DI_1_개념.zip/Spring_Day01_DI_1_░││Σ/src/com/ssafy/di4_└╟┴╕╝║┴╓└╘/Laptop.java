package com.ssafy.di4_의존성주입;

public class Laptop implements Computer{
	//필드...
	
	
	public String getInfo() {
		return "랩톱";
	}
}
