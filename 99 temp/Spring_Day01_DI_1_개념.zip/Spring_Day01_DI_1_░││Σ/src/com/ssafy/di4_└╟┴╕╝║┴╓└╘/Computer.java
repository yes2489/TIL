package com.ssafy.di4_의존성주입;

public interface Computer {
	String getInfo();
}
